import pyodbc
import datetime
import jwt
import uuid

from flask import current_app
from flask import jsonify
from utils.password_utils import encrypt_text, verify_encrypted_text
from utils.user_utils import validate_email, retrieve_user, validate_date_of_birth
from utils.storage_utils import upload_image
from utils.face_utils import call_face_api

from flask import request


def register():
    response = {
        "success": False,
        "response": " "
    }

    email = request.form.get('email')
    password = request.form.get('password')
    first_name = request.form.get('firstName')
    last_name = request.form.get('lastName')
    phone = request.form.get('phone')
    gender = request.form.get('gender')
    date_of_birth = request.form.get('birth')
    address = request.form.get('address')
    id_number = request.form.get('id_number')
    document_photo = request.files.get('document_photo')
    document_photo_extension = document_photo.filename.split('.')[-1]
    face_photo = request.files.get('face_photo')
    approved = 0

    document_filename = str(uuid.uuid4()) + "." + document_photo_extension
    document_photo.filename = document_filename

    if not all([email, password, first_name, last_name, phone, document_photo, face_photo, gender, date_of_birth, address, id_number]):
        response["response"] = "All required fields should be provided"
        return jsonify(response), 400

    if not validate_email(email):
        response["response"] = "Email is invalid"
        return jsonify(response), 400

    if not validate_date_of_birth(date_of_birth):
        response["response"] = "Date of birth invalid. You must be at least 18 years old"
        return jsonify(response), 400

    status = call_face_api(document_photo, face_photo)

    if status:
        approved = 1

    encrypted_password = encrypt_text(password)

    conn = pyodbc.connect(current_app.config['SQL_CONNECTION_STRING'])

    try:
        if retrieve_user(conn=conn, id=None, email=email):
            response['response'] = 'This email is already registered'
            return jsonify(response), 400

        document_photo.stream.seek(0)
        upload_image(document_photo)

        cursor = conn.cursor()
        cursor.execute("INSERT INTO users (firstName, lastName, email, phone, password, "
                       "approved, gender, date_of_birth, address, id_number, document_filename) "
                       "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                       (first_name, last_name, email, phone, encrypted_password,
                        approved, gender, date_of_birth, address, id_number, document_filename))
        conn.commit()
        response['success'] = True
        if approved:
            response['response'] = "User registered successfully"
        else:
            response['response'] = "Face and document do not match. Wait for admin to approve your registration"

    except pyodbc.Error as e:
        response['response'] = "Error: " + str(e)
        return jsonify(response), 500

    finally:
        conn.close()

    return jsonify(response), 201


def login():
    response = {
        "success": False,
        "response": " "
    }

    body = request.json
    email = body['email']
    password = body['password']

    if email and password:
        conn = pyodbc.connect(current_app.config['SQL_CONNECTION_STRING'])

        try:
            user = retrieve_user(conn=conn, id=None, email=email)

            if user and verify_encrypted_text(user[2], password):
                token = jwt.encode(
                    {'isAdmin': user[4], 'email': user[1], 'id': user[0],
                     'exp': datetime.datetime.utcnow() + datetime.timedelta(hours=1)},
                    current_app.config['SECRET_KEY'], algorithm="HS256")
                response["success"] = True
                response['response'] = dict({
                    "token": token,
                    "firstName": user[3],
                    "isAdmin": user[4]
                })
                return jsonify(response), 200
            else:
                response["response"] = "Wrong email or password"
                return jsonify(response), 400

        except pyodbc.Error as e:
            response['response'] = "Error: " + str(e)
            return jsonify(response), 500

        finally:
            conn.close()

    response["response"] = "Email or password not entered"
    return jsonify(response), 400


def approve_user_registration(user_id):
    response = {
        "success": False,
        "response": " "
    }

    conn = pyodbc.connect(current_app.config['SQL_CONNECTION_STRING'])
    user = retrieve_user(conn=conn, id=user_id, email=None)

    if user is None:
        response["response"] = f"User with id = {user_id} does not exist"
        return jsonify(response), 400

    if user[5] == 1:
        response["response"] = f"User with id = {user_id} is already approved"
        return jsonify(response), 400

    cursor = conn.cursor()
    cursor.execute("UPDATE users SET approved = 1 WHERE id = ?", (user_id))
    cursor.commit()
    conn.close()

    response["success"] = True
    response["response"] = "User approved!"

    return jsonify(response), 200
