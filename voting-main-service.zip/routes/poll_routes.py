import datetime

import pyodbc

from flask import jsonify, request, current_app
from utils.polls_utils import retrieve_polls, validate_date_format, does_candidate_exist_for_poll, can_user_vote, \
    validate_date_not_in_past, does_face_matches


def get_polls(user_id, id=None, is_user_admin=False):
    response = {
        "success": True,
        "response": ""
    }

    conn = pyodbc.connect(current_app.config['SQL_CONNECTION_STRING'])

    response["response"] = retrieve_polls(conn, user_id, id, is_user_admin)

    conn.close()

    return jsonify(response), 200


def add_poll():
    response = {
        "success": False,
        "response": " "
    }

    poll = request.json

    fields_to_check = ['name', 'openUntil', 'candidates', 'description', 'filter']
    for field in fields_to_check:
        if field not in poll or len(poll[field]) == 0:
            response["response"] = f"Field {field} should be provided!"
            return jsonify(response), 400

    if not validate_date_format(poll['openUntil']):
        response["response"] = f"Field openUntil should be in format YYYY-MM-DD"
        return jsonify(response), 400

    if not validate_date_not_in_past(poll['openUntil']):
        response["response"] = f"Date until poll is open can not be in the past"
        return jsonify(response), 400

    if len(poll['candidates']) == 0:
        response["response"] = f"Field candidates should not be an empty list"
        return jsonify(response), 400

    conn = pyodbc.connect(current_app.config['SQL_CONNECTION_STRING'])

    cursor = conn.cursor()
    cursor.execute("INSERT INTO polls (name, openUntil, description, filter) VALUES (?, ?, ?, ?)",
                   (poll['name'], poll['openUntil'], poll['description'], poll['filter']))
    conn.commit()

    if current_app.config['DEVELOPMENT']:
        # TODO: Test if it works for Prod as well
        cursor.execute("SELECT LAST_INSERT_ID()")
        inserted_poll_id = cursor.fetchone()[0]
    else:
        cursor.execute("SELECT IDENT_CURRENT('polls')")
        inserted_poll_id = cursor.fetchone()[0]

    for candidate in poll['candidates']:
        cursor.execute("INSERT INTO candidates (name, poll_id) VALUES (?, ?)", candidate, inserted_poll_id)
        cursor.commit()

    conn.close()

    response['success'] = True
    response['response'] = "Poll added successfully"

    return jsonify(response), 201


def add_vote(user_id):
    response = {
        "success": False,
        "response": " "
    }

    vote = {
        'pollId': request.form.get('pollId'),
        'candidateId': request.form.get('candidateId')
    }
    face_photo = request.files.get('face_photo')

    if not face_photo:
        response["response"] = f"Field face_photo should be provided!"
        return jsonify(response), 400

    fields_to_check = ['pollId', 'candidateId']
    for field in fields_to_check:
        if field not in vote:
            response["response"] = f"Field {field} should be provided!"
            return jsonify(response), 400

    conn = pyodbc.connect(current_app.config['SQL_CONNECTION_STRING'])

    if not can_user_vote(conn, user_id, vote['pollId']):
        response['response'] = "User already voted!"
        conn.close()
        return jsonify(response), 400

    if not does_candidate_exist_for_poll(conn, vote['candidateId'], vote['pollId']):
        response['response'] = "Candidate or poll do not exist!"
        conn.close()
        return jsonify(response), 400

    if not does_face_matches(conn, user_id, face_photo):
        response['response'] = "Face does not match. Contact an administrator!"
        conn.close()
        return jsonify(response), 400

    cursor = conn.cursor()

    timestamp_vote = datetime.datetime.now()
    cursor.execute("INSERT INTO candidate_votes(candidate_id, poll_id, timestamp) VALUES (?, ?, ?)", (vote['candidateId'], vote['pollId'], timestamp_vote, ))
    cursor.execute("INSERT INTO user_votes(user_id, poll_id) VALUES (?, ?)", (user_id, vote['pollId'], ))
    cursor.commit()

    conn.close()

    response['success'] = True
    response['response'] = "Voted added"
    return jsonify(response), 201


def close_poll(poll_id):
    response = {
        "success": True,
        "response": "Poll closed"
    }

    conn = pyodbc.connect(current_app.config['SQL_CONNECTION_STRING'])
    cursor = conn.cursor()
    cursor.execute("UPDATE polls SET status = 'CLOSED' WHERE id = ?", (poll_id, ))
    cursor.commit()
    conn.close()

    return jsonify(response), 200
