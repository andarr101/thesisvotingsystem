import re
from datetime import datetime
from utils.storage_utils import retrieve_file
from utils.face_utils import call_face_api
from utils.user_utils import retrieve_user


def retrieve_poll_results(conn, id):
    cursor = conn.cursor()

    query = "SELECT COUNT(*) as votes, candidate_id FROM candidate_votes " \
            "WHERE poll_id = ? " \
            "GROUP BY candidate_id " \
            "ORDER BY votes DESC"

    cursor.execute(query, (id, ))
    columns = ["votes", "candidate_id"]
    results = []
    for row in cursor.fetchall():
        results.append(dict(zip(columns, row)))

    return results


def retrieve_polls(conn, user_id, id=None, is_user_admin=False):
    user_address = retrieve_user(conn, user_id, None)[6]
    cursor = conn.cursor()

    query = "SELECT " \
            "p.id, p.name, p.openUntil, p.description, p.status, p.filter, " \
            "CASE WHEN uv.user_id IS NOT NULL THEN 1 ELSE 0 END AS voted " \
            "FROM polls p LEFT JOIN user_votes uv ON p.id = uv.poll_id AND uv.user_id = ? " \

    if id:
        query = query + " WHERE p.id = ?"
        query = query + " ORDER BY p.openUntil ASC"

        cursor.execute(query, (user_id, id))
        poll = cursor.fetchone()
        if not is_user_admin and (len(poll[5]) > 0 and not poll[5] in user_address):
            return {"error": "You are not allowed to view this poll"}

        cursor.execute("SELECT id, name FROM candidates WHERE poll_id = ?", (id))
        columns = ["id", "name"]
        candidates = []
        for row in cursor.fetchall():
            candidates.append(dict(zip(columns, row)))
        results = None
        if 'CLOSED' in poll[4]:
            results = retrieve_poll_results(conn, id)

        return {
            "name": poll[1],
            "openUntil": poll[2],
            "description": poll[3],
            "status": poll[4],
            "voted": poll[6],
            "candidates": candidates,
            "results": results
        }

    query = query + " ORDER BY p.openUntil ASC"
    print(query)
    cursor.execute(query, (user_id, ))
    columns = ["id", "name", "openUntil", "description", "status", "filter", "voted"]
    results = []
    for row in cursor.fetchall():
        print(row)
        if is_user_admin or (user_address is None or len(row[5]) == 0 or row[5] in user_address):
            results.append(dict(zip(columns, row)))

    return results


def can_user_vote(conn, user_id, poll_id):
    cursor = conn.cursor()

    cursor.execute("SELECT user_id, poll_id FROM user_votes WHERE user_id = ? AND poll_id = ?", (user_id, poll_id, ))
    result = cursor.fetchone()

    if result is not None:
        return False
    return True


def does_candidate_exist_for_poll(conn, candidate_id, poll_id):
    cursor = conn.cursor()

    cursor.execute("SELECT id, poll_id FROM candidates WHERE id = ? AND poll_id = ?", (candidate_id, poll_id, ))
    result = cursor.fetchone()

    if result is None:
        return False
    return True


def validate_date_format(date_string):
    pattern = re.compile(r'^\d{4}-\d{2}-\d{2}$')

    if pattern.match(date_string):
        return True
    return False


def validate_date_not_in_past(date_string):
    try:
        date_object = datetime.strptime(date_string, '%Y-%m-%d')
        current_date = datetime.now().date()

        if date_object.date() >= current_date:
            return True

        return False
    except ValueError:
        return False


def does_face_matches(conn, user_id, face_photo):
    cursor = conn.cursor()

    cursor.execute("SELECT document_filename FROM users WHERE id = ?", (user_id,))
    document_filename = cursor.fetchone()[0]
    document_photo = retrieve_file(document_filename)

    status = call_face_api(document_photo, face_photo)
    return status
