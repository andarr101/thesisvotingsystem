from flask_bcrypt import Bcrypt

bcrypt = Bcrypt()


def encrypt_text(plain_text):

    return bcrypt.generate_password_hash(plain_text).decode('utf-8')


def verify_encrypted_text(encrypted_text, plain_text):

    return bcrypt.check_password_hash(encrypted_text, plain_text)
