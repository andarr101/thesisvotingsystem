import re
from datetime import datetime, timedelta


def retrieve_user(conn, id, email):
    cursor = conn.cursor()
    if id is None:
        cursor.execute("SELECT id, email, password, firstName, isAdmin, approved FROM users WHERE email = ?", (email,))
        return cursor.fetchone()

    cursor.execute("SELECT id, email, password, firstName, isAdmin, approved FROM users WHERE id = ?", (id, ))
    return cursor.fetchone()


def validate_email(email):
    regex = '^[a-z0-9]+[\._]?[a-z0-9]+[@]\w+[.]\w{2,3}$'

    if re.search(regex, email):
        return True

    return False


def validate_date_of_birth(date_of_birth):
    # Regex pattern for YYYY-MM-DD format
    date_pattern = re.compile(r'^\d{4}-\d{2}-\d{2}$')

    # Check if date_of_birth matches the pattern
    if not date_pattern.match(date_of_birth):
        return False

    # Convert date_of_birth string to datetime object
    try:
        dob_date = datetime.strptime(date_of_birth, '%Y-%m-%d')
    except ValueError:
        return False

    # Calculate age
    today = datetime.today()
    age = today.year - dob_date.year - ((today.month, today.day) < (dob_date.month, dob_date.day))

    # Check if age is at least 18 years old
    if age < 18:
        return False

    return True
