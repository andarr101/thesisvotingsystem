from azure.storage.blob import BlobServiceClient, generate_blob_sas, BlobSasPermissions
from flask import current_app


def upload_image(file):
    connection_string = current_app.config['STORAGE_CONTAINER']
    blob_service_client = BlobServiceClient.from_connection_string(connection_string)
    container_name = "documents"
    container_client = blob_service_client.get_container_client(container_name)

    blob_name = file.filename
    blob_client = container_client.get_blob_client(blob_name)
    blob_client.upload_blob(file)


def retrieve_file(filename):
    connection_string = current_app.config['STORAGE_CONTAINER']
    blob_service_client = BlobServiceClient.from_connection_string(connection_string)
    container_name = "documents"
    container_client = blob_service_client.get_container_client(container_name)
    blob_client = container_client.get_blob_client(filename)
    blob_content = blob_client.download_blob().readall()
    return blob_content
