import requests
from flask import current_app


def call_face_api(document_photo, face_photo):
    URL_FACE_MATCHING = f"{current_app.config['HOST_FACE_MATCHING']}/validate_face"

    try:
        face_matching_response = requests.post(URL_FACE_MATCHING, files={
            "file1": document_photo,
            "file2": face_photo
        })

        print(face_matching_response.json())
        return face_matching_response.json().get("status")
    except requests.RequestException as e:
        print("Error making API call:", e)
        return {
            "status": -1
        }
