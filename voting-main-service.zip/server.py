import datetime
import os
import jwt

from functools import wraps
from flask import Flask, request, jsonify
from flask_cors import CORS
import pyodbc
import routes.user_routes as user_routes
import routes.poll_routes as poll_routes


app = Flask(__name__)
env_config = os.getenv("APP_SETTINGS", "config.DevelopmentConfig")
app.config.from_object(env_config)
CORS(app)

############################################################
# PRIVATE ROUTES
############################################################


@app.route('/api/ping', methods=['GET'])
def ping():
    return "OK!", 200


@app.route('/api/testdb', methods=['GET'])
def test_db():
    try:
        conn = pyodbc.connect(app.config['SQL_CONNECTION_STRING'])
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM users")
        pass
    except pyodbc.Error as e:
        return "NOT WORKING! Error: " + str(e), 400
    finally:
        return "OK!", 200

#############################################################


def retrieve_user_data():
    token = request.headers.get('Authorization')
    token = token.replace('Bearer ', '')
    return jwt.decode(token, app.config['SECRET_KEY'], algorithms="HS256")


def admin_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        token = request.headers.get('Authorization')
        token = token.replace('Bearer ', '')
        response = {
            "success": False,
            "response": " "
        }
        if not token:
            response["response"] = 'Token is missing!'
            return jsonify(response), 401
        try:
            data = jwt.decode(token, app.config['SECRET_KEY'], algorithms="HS256")
            if data['isAdmin'] == 0:
                response["response"] = "You must be an admin to access this route"
                return jsonify(response), 403
        except Exception as e:
            print(e)
            response["response"] = "Token is invalid!"
            return jsonify(response), 401
        return f(*args, **kwargs)

    return decorated


def token_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        token = request.headers.get('Authorization')
        token = token.replace('Bearer ', '')
        response = {
            "success": False,
            "response": " "
        }
        if not token:
            response["response"] = 'Token is missing!'
            return jsonify(response), 401
        try:
            data = jwt.decode(token, app.config['SECRET_KEY'], algorithms="HS256")
        except Exception as e:
            print(e)
            response["response"] = "Token is invalid!"
            return jsonify(response), 401
        return f(*args, **kwargs)
    return decorated

#############################################################


@app.route('/api/register', methods=['POST'])
def register():
    return user_routes.register()


@app.route('/api/login', methods=['POST'])
def login():
    return user_routes.login()


@app.route('/api/polls', methods=['GET'])
@token_required
def get_polls():
    is_user_admin = retrieve_user_data()['isAdmin']
    user_id = retrieve_user_data()['id']
    return poll_routes.get_polls(id=request.args.get('id'), user_id=user_id, is_user_admin=is_user_admin)


@app.route('/api/poll', methods=['POST'])
@admin_required
def add_poll():
    return poll_routes.add_poll()


@app.route('/api/approve/registration', methods=['POST'])
@admin_required
def approve_user_registration():
    return user_routes.approve_user_registration(request.args.get('id'))


@app.route('/api/close', methods=['POST'])
@admin_required
def close_poll():
    return poll_routes.close_poll(request.args.get('id'))


@app.route('/api/vote', methods=['POST'])
@token_required
def vote_poll():
    user_id = retrieve_user_data()['id']
    return poll_routes.add_vote(user_id)


@app.route('/api/requests', methods=['GET'])
@admin_required
def get_requests():
    return user_routes.get_requests()


if __name__ == '__main__':
    print(f"[{datetime.datetime.now()}] Application started")
    print("DB Connection: ", test_db())
    app.run()
