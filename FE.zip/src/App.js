import { BrowserRouter, Routes, Route } from "react-router-dom";

import Register from "./pages/Register";
import Login from "./pages/Login";
import NoPage from "./pages/NoPage";
import Home from "./pages/Home";
import VotingDetails from "./pages/VotingDetails";
import PendingRequests from "./pages/PendingRequests";

export default function App() {
  const isAdmin = localStorage.getItem('isAdmin');

  return (
    <>
      <BrowserRouter>
        <Routes>
          <Route index element={<Home />} />
          <Route path="/register" element={<Register />} />
          <Route path="/login" element={<Login />} />
          <Route path="/details" element={<VotingDetails />} />
          {isAdmin && <Route path="/pending-requests" element={<PendingRequests />} /> }
          <Route path="*" element={<NoPage />} />
        </Routes>
      </BrowserRouter>
    </>
  );
}
