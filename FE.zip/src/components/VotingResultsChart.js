import * as React from "react";
import { BarChart } from "@mui/x-charts/BarChart";

export default function VotingResultsChart({ votingResults, candidateNames }) {
  const candidateIds =
    votingResults &&
    votingResults
      .map((result) => result.candidate_id)
      .map((id) => {
        const candidate = candidateNames.find((item) => item.id === id);
        if (candidate) return candidate.name;
        else return null;
      });
  const votes = votingResults && votingResults.map((result) => result.votes);

  return (
    <BarChart
      xAxis={[{ scaleType: "band", data: candidateIds }]}
      series={[{ data: votes }]}
      width={500}
      height={300}
    />
  );
}
