import React from "react";
import { useNavigate } from "react-router-dom";
import {
  MDBCard,
  MDBCardBody,
  MDBCardTitle,
  MDBCardText,
  MDBBtn,
} from "mdb-react-ui-kit";

export default function VoteCard({ id, vote }) {
  const navigate = useNavigate();
  const status = vote.status.includes("ACTIVE");
  const isAdmin = localStorage.getItem("isAdmin");
  const token = localStorage.getItem('token');

  const handleCardClick = async () => {
    if(isAdmin && status)
    {
      await fetch(`http://127.0.0.1:5000/api/close?id=${id}`, {
        method: "POST",
        headers: {
          "Authorization": "Bearer " + token,
        }
      })
    }
    else {

      localStorage.setItem('status', vote.status);
      navigate(`/details?id=${id}`);
    }
  };

  return (
    <MDBCard
      style={{ width: "40%" }}
      className="hover-shadow"
      onClick={handleCardClick}
    >
      <MDBCardBody>
        <MDBCardTitle>{vote.name}</MDBCardTitle>
        <MDBCardText>Open until: {vote.openUntil}</MDBCardText>
        <MDBCardText>{vote.description || 'No description'}</MDBCardText>
        {isAdmin && status && <MDBBtn>Close vote</MDBBtn>}
        {!isAdmin && status && <MDBBtn>Vote</MDBBtn>}
        {!status && (
          <MDBBtn color="secondary" disabled>
            Vote closed
          </MDBBtn>
        )}
      </MDBCardBody>
    </MDBCard>
  );
}
