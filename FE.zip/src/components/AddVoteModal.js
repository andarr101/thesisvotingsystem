import React, { useState } from "react";
import {
  MDBBtn,
  MDBModal,
  MDBModalDialog,
  MDBModalContent,
  MDBModalHeader,
  MDBModalTitle,
  MDBModalBody,
  MDBModalFooter,
  MDBInput,
} from "mdb-react-ui-kit";
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import { DateField } from '@mui/x-date-pickers/DateField';

import "../css/AddVoteModal.css";

export default function AddVoteModal(props) {
  const [question, setQuestion] = useState("");
  const [description, setDescription] = useState("");
  const [expirationDate, setExpirationDate] = useState("");
  const [filter, setFilter] = useState("");
  const [options, setOptions] = useState([""]);
  const [loginStatus, setLoginStatus] = useState("");
  const token = localStorage.getItem('token');

  const handleQuestionChange = (e) => {
    setQuestion(e.target.value);
  };

  const handleDescriptionChange = (e) => {
    setDescription(e.target.value);
  };

  const handleFilterChange = (e) => {
    setFilter(e.target.value);
  };

  const handleOptionChange = (index, e) => {
    const updatedOptions = [...options];
    updatedOptions[index] = e.target.value;
    setOptions(updatedOptions);
  };

  const addOption = () => {
    setOptions([...options, ""]);
  };

  const removeOption = (index) => {
    const updatedOptions = [...options];
    updatedOptions.splice(index, 1);
    setOptions(updatedOptions);
  };

  const formatExpirationDate = (birthDate) => {
    let month = +birthDate.$M + 1;
    if (month < 10) {
      month = '0' + month;
    }

    let day = +birthDate.$D;
    if (day < 10) {
      day = '0' + day;
    }

    return birthDate.$y + '-' + month + '-' + day;
  }

  const onSubmit = async (body) => {
    const {question: name, description, options: candidates, date: openUntil, filter} = body;

    try {
      const response = await fetch(
        "http://127.0.0.1:5000/api/poll",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "Authorization": "Bearer " + token,
          },
          body: JSON.stringify({ name, description, candidates, openUntil, filter }),
        }
      );

      if (response.ok) {
        const data = await response.json();
        setLoginStatus("Poll created successfully!");
      } else {
        setLoginStatus("Adding poll failed.");
      }
    } catch (error) {
      console.error("Error when adding poll:", error);
      setLoginStatus("Error when adding poll.");
    }
  };

  const handleSubmit = () => {
    const date = formatExpirationDate(expirationDate);
    props.toggleModal();
    onSubmit({ question, options, description, filter, date });
    // onClose();
  };

  return (
    <>
      <MDBModal
        tabIndex="-1"
        open={props.showModal}
        setOpen={props.setShowModal}
      >
        <MDBModalDialog centered>
          <MDBModalContent>
            <MDBModalHeader>
              <MDBModalTitle>Add new vote</MDBModalTitle>
              <MDBBtn
                className="btn-close"
                color="none"
                onClick={props.toggleModal}
              ></MDBBtn>
            </MDBModalHeader>
            <MDBModalBody className="fields">
              <MDBInput
                required
                label="Description"
                value={description}
                onChange={handleDescriptionChange}
              />
              <MDBInput
                required
                label="Question"
                value={question}
                onChange={handleQuestionChange}
              />
           
              <LocalizationProvider dateAdapter={AdapterDayjs}>
                  <DateField label="Expiration Date" onChange={(newValue) => setExpirationDate(newValue)} />
              </LocalizationProvider>
              <MDBInput
                label="Filter by"
                value={filter}
                onChange={handleFilterChange}
              />

              {options.map((option, index) => (
                <div
                  key={index}
                  className="d-flex align-items-center options-container"
                >
                  <MDBInput
                    className="me-2"
                    label={`Option ${index + 1}`}
                    value={option}
                    onChange={(e) => handleOptionChange(index, e)}
                  />
                  <MDBBtn
                    color="danger"
                    size="sm"
                    onClick={() => removeOption(index)}
                  >
                    X
                  </MDBBtn>
                </div>
              ))}

              <MDBBtn
                color="primary"
                size="sm"
                onClick={addOption}
                className="add-option-btn"
              >
                Add Option
              </MDBBtn>
            </MDBModalBody>
            <MDBModalFooter>
              <MDBBtn color="secondary" onClick={props.toggleModal}>
                Close
              </MDBBtn>
              <MDBBtn onClick={handleSubmit}>Submit</MDBBtn>
            </MDBModalFooter>
          </MDBModalContent>
        </MDBModalDialog>
      </MDBModal>
    </>
  );
}
