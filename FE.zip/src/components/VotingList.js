import React, { useEffect, useState } from "react";

import VoteCard from "./VoteCard";
import "../css/VotingList.css";

export default function VotingList() {
  const [votes, setVotes] = useState([]);
  const token = localStorage.getItem("token");

  useEffect(() => {
    fetch("http://127.0.0.1:5000/api/polls", {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    })
      .then((response) => response.json())
      .then((data) => {
        setVotes(data.response);
      })
      .catch((error) => console.error("Error fetching votes: ", error));
  }, []);

  return (
    <>
      {Array.isArray(votes) && votes.length && (
        <div className="list-container">
          {votes.map((vote) => (
            <VoteCard id={vote.id} key={vote.id} vote={vote} />
          ))}
        </div>
      )}
    </>
  );
}
