import React from "react";
import { useNavigate } from "react-router-dom";
import {
  MDBContainer,
  MDBNavbar,
  MDBNavbarBrand,
  MDBNavbarNav,
  MDBNavbarItem,
  MDBNavbarLink,
  MDBCollapse,
  MDBBtn,
} from "mdb-react-ui-kit";

import "../css/Home.css";

export default function Navbar() {
  const navigate = useNavigate();
  const firstName = localStorage.getItem("firstname");
  const isAdmin = +localStorage.getItem("isAdmin");

  const handleHomeClick = () => {
    navigate("/");
  };

  const handleRequestsClick = () => {
    navigate("/pending-requests");
  };

  const handleLogout = () => {
    navigate("/login");
    localStorage.clear();
  };

  return (
    <MDBNavbar sticky expand="lg" dark bgColor="dark">
      <MDBContainer fluid>
        <MDBNavbarBrand href="/">Awesome Voting App</MDBNavbarBrand>

        <MDBCollapse navbar>
          <MDBNavbarNav
            style={{ display: "flex", justifyContent: "space-between" }}
          >
            <div className="flex-container">
              <MDBNavbarItem>
                <MDBNavbarLink
                  active
                  aria-current="page"
                  onClick={handleHomeClick}
                >
                  Home
                </MDBNavbarLink>
              </MDBNavbarItem>
              {isAdmin ? 
                <MDBNavbarItem>
                  <MDBNavbarLink
                    active
                    aria-current="page"
                    onClick={handleRequestsClick}
                  >
                    Pending Requests
                  </MDBNavbarLink>
                </MDBNavbarItem>
              : null}
            </div>
            <div className="flex-container">
              <MDBNavbarItem>
                <MDBNavbarLink disabled style={{ color: "white" }}>
                  Hi, {firstName}
                </MDBNavbarLink>
              </MDBNavbarItem>
              <MDBNavbarItem>
                <MDBBtn className="me-1" color="success" onClick={handleLogout}>
                  Logout
                </MDBBtn>
              </MDBNavbarItem>
            </div>
          </MDBNavbarNav>
        </MDBCollapse>
      </MDBContainer>
    </MDBNavbar>
  );
}
