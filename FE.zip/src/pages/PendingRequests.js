import { useState, useEffect } from "react";
import {
  MDBCard,
  MDBCardBody,
  MDBCardTitle,
  MDBCardText,
  MDBBtn,
} from "mdb-react-ui-kit";
import background from "../assets/bkgg.avif";
import Navbar from "../components/Navbar";
import "../css/Home.css";

export default function PendingRequests() {
  const token = localStorage.getItem("token");
  const [pendingRequests, setPendingRequests] = useState([]);
  const [triggerUpdateList, setTriggerUpdateList] = useState(false);

  useEffect(() => {
    fetch("http://127.0.0.1:5000/api/requests", {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    })
      .then((response) => response.json())
      .then((data) => {
        setPendingRequests(data.response);
      })
      .catch((error) =>
        console.error("Error fetching pending requests: ", error)
      );
  }, [triggerUpdateList]);

  const approveRequest = (id) => {
    fetch(
      `http://127.0.0.1:5000/api/approve/registration?id=${id}`,
      {
        headers: {
          Authorization: `Bearer ${token}`,
        },
        method: "POST",
      }
    )
      .then((response) => response.json())
      .then((data) => {
        alert(data.response);
      });

    setTriggerUpdateList(!triggerUpdateList);
  };
  return (
    <div id="container">
      <div
        style={{
          backgroundImage: `url(${background})`,
          backgroundSize: "cover",
          height: "400px",
        }}
      >
        <Navbar />

        <div style={{ height: "330px" }}></div>
        <div className="flex-wrapper">
          <div className="content-wrapper">
            <h3>Pending requests:</h3>
            <div className="pending-requests-wrapper">
              {pendingRequests.map((request) => (
                <div className="requestCard">
                  <MDBCard>
                    <MDBCardBody>
                      <MDBCardTitle>{request.email}</MDBCardTitle>
                      <MDBCardText>
                        <p>Photo id: {request.document_filename}</p>
                        <p>Photo taken: {request.face_filename}</p>
                      </MDBCardText>
                      <MDBBtn onClick={() => approveRequest(request.id)}>
                        Approve
                      </MDBBtn>
                    </MDBCardBody>
                  </MDBCard>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
