import { useState } from "react";
import { MDBBtn } from "mdb-react-ui-kit";

import background from "../assets/bkgg.avif";
import VotingList from "../components/VotingList";
import AddVoteModal from "../components/AddVoteModal";
import "../css/Home.css";
import Navbar from "../components/Navbar";

export default function Home() {
  const [showModal, setShowModal] = useState(false);
  const isAdmin = localStorage.getItem("isAdmin");

  const toggleModal = () => {
    setShowModal(!showModal);
  };

  return (
    <div id="container">
      <div
        style={{
          backgroundImage: `url(${background})`,
          backgroundSize: "cover",
          height: "400px",
        }}
      >
        <Navbar />

        <div style={{ height: "330px" }}></div>
        <div className="flex-wrapper">
          <div className="new-vote">
            <h3>Voting list</h3>

            {isAdmin !== "0" && (
              <div>
                <MDBBtn className="me-1" color="success" onClick={toggleModal}>
                  Add new vote
                </MDBBtn>
              </div>
            )}
            {showModal && (
              <AddVoteModal
                showModal={showModal}
                setShowModal={setShowModal}
                toggleModal={toggleModal}
              />
            )}
          </div>
        </div>
        <VotingList />
      </div>
    </div>
  );
}
