export default function NoPage() {
  return (
    <>
      <h2>Error 404: Not found</h2>
    </>
  );
}
