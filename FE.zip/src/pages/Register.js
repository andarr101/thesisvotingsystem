import React, { useState, useEffect } from "react";
import dayjs from "dayjs";
import moment from "moment";
import {
  MDBBtn,
  MDBContainer,
  MDBCard,
  MDBCardBody,
  MDBCardImage,
  MDBRow,
  MDBCol,
  MDBInput,
} from "mdb-react-ui-kit";
import InputLabel from "@mui/material/InputLabel";
import MenuItem from "@mui/material/MenuItem";
import Select from "@mui/material/Select";
import FormControl from "@mui/material/FormControl";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
import { DatePicker } from "@mui/x-date-pickers/DatePicker";

import "../css/Register.css";
import { useNavigate } from "react-router-dom";

function Register() {
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [password, setPassword] = useState("");
  const [address, setAddress] = useState("");
  const [gender, setGender] = useState("");
  const [idNumber, setIdNumber] = useState("");
  const [birthDate, setBirthDate] = useState(dayjs("2022-04-17"));
  const [file, setFile] = useState(null);
  const [cameraImage, setCameraImage] = useState(null);
  const [registrationStatus, setRegistrationStatus] = useState("");
  const navigate = useNavigate();

  useEffect(() => {
    document.body.style.backgroundColor = "#9A616D";
    return () => {
      document.body.style.backgroundColor = null;
    };
  }, []);

  const formatBirthDate = (birthDate) => {
    let month = +birthDate.$M + 1;
    if (month < 10) {
      month = '0' + month;
    }

    let day = +birthDate.$D;
    if (day < 10) {
      day = '0' + day;
    }

    return birthDate.$y + '-' + month + '-' + day;
  }

  const onSubmit = async (event) => {
    const birth = formatBirthDate(birthDate);
    event.preventDefault();

    const formData = new FormData();
    formData.append("firstName", firstName);
    formData.append("lastName", lastName);
    formData.append("email", email);
    formData.append("phone", phone);
    formData.append("password", password);
    formData.append("address", address);
    formData.append("birth", birth);
    formData.append("gender", gender);
    formData.append("id_number", idNumber);
    formData.append("document_photo", file);

    if (cameraImage) {
      const blob = await fetch(cameraImage).then((response) => response.blob());
      formData.append("face_photo", blob, "camera-image.png");
    }

    try {
      const response = await fetch(
        "http://127.0.0.1:5000/api/register",
        {
          method: "POST",
          body: formData,
        }
      );

      if (response.ok) {
        const data = await response.json();
        setRegistrationStatus("Registration successful!");
        navigate("/login");
        alert(data.response);
      } else {
        setRegistrationStatus("Registration failed.");
      }
    } catch (error) {
      console.error("Error during registration:", error);
      setRegistrationStatus("Error during registration.");
    }
  };

  const handleFirstNameChange = (event) => {
    setFirstName(event.target.value);
  };
  const handleLastNameChange = (event) => {
    setLastName(event.target.value);
  };
  const handleEmailChange = (event) => {
    setEmail(event.target.value);
  };
  const handlePhoneChange = (event) => {
    setPhone(event.target.value);
  };
  const handlePasswordChange = (event) => {
    setPassword(event.target.value);
  };
  const handleFileChange = (event) => {
    const selectedFile = event.target.files[0];
    setFile(selectedFile);
  };
  const handleGenderChange = (event) => {
    setGender(event.target.value);
  };
  const handleAddressChange = (event) => {
    setAddress(event.target.value);
  };
  const handleIdNumberChange = (event) => {
    setIdNumber(event.target.value);
  };

  const handleCameraCapture = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true });
      const video = document.createElement("video");
      document.body.appendChild(video);
      video.srcObject = stream;
      await video.play();

      const canvas = document.createElement("canvas");
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      canvas
        .getContext("2d")
        .drawImage(video, 0, 0, canvas.width, canvas.height);
      const imageUrl = canvas.toDataURL("image/png");

      setCameraImage(imageUrl);

      stream.getTracks().forEach((track) => track.stop());
      video.remove();
      canvas.remove();
    } catch (error) {
      console.error("Error accessing camera:", error);
    }
  };

  return (
    <MDBContainer fluid className="card-container">
      <MDBRow className="d-flex justify-content-center align-items-center h-100">
        <MDBCol>
          <MDBCard className="my-4">
            <MDBRow className="g-0">
              <MDBCol md="6" className="d-none d-md-block">
                <MDBCardImage
                  src="https://mdbcdn.b-cdn.net/img/Photos/new-templates/bootstrap-registration/img4.webp"
                  alt="Sample photo"
                  className="rounded-start"
                  fluid
                />
              </MDBCol>

              <MDBCol md="6">
                <MDBCardBody className="text-black d-flex flex-column justify-content-center">
                  <h3 className="mb-5 text-uppercase fw-bold">Register</h3>

                  <MDBRow>
                    <MDBCol md="6">
                      <MDBInput
                        wrapperClass="mb-4"
                        label="First Name"
                        size="lg"
                        id="form1"
                        type="text"
                        onChange={handleFirstNameChange}
                      />
                    </MDBCol>

                    <MDBCol md="6">
                      <MDBInput
                        wrapperClass="mb-4"
                        label="Last Name"
                        size="lg"
                        id="form2"
                        type="text"
                        onChange={handleLastNameChange}
                      />
                    </MDBCol>
                  </MDBRow>

                  <MDBRow>
                    <MDBCol md="6">
                      <MDBInput
                        wrapperClass="mb-4"
                        label="Email"
                        size="lg"
                        id="form3"
                        type="email"
                        onChange={handleEmailChange}
                      />
                    </MDBCol>

                    <MDBCol md="6">
                      <MDBInput
                        wrapperClass="mb-4"
                        label="Phone"
                        size="lg"
                        id="form4"
                        type="text"
                        onChange={handlePhoneChange}
                      />
                    </MDBCol>
                  </MDBRow>

                  <div className="row-data">
                    <div className="gender-container">
                      <FormControl sx={{ minWidth: 120 }}>
                        <InputLabel id="gender">Gender</InputLabel>
                        <Select
                          labelId="gender"
                          id="gender"
                          value={gender}
                          label="Gender"
                          onChange={handleGenderChange}
                        >
                          <MenuItem value={"M"}>Male</MenuItem>
                          <MenuItem value={"F"}>Female</MenuItem>
                          <MenuItem value={"O"}>Other</MenuItem>
                        </Select>
                      </FormControl>
                    </div>

                    <LocalizationProvider
                      dateAdapter={AdapterDayjs}
                      size="small"
                    >
                      <DatePicker
                        label="Birth date"
                        name="birthDate"
                        onChange={(newValue) => setBirthDate(newValue)}
                      />
                    </LocalizationProvider>
                  </div>

                  <MDBInput
                    wrapperClass="mb-4"
                    label="Adress"
                    size="lg"
                    id="form4"
                    type="text"
                    onChange={handleAddressChange}
                  />

                  <MDBInput
                    wrapperClass="mb-4"
                    label="Id Number"
                    size="lg"
                    id="form4"
                    type="text"
                    onChange={handleIdNumberChange}
                  />

                  <MDBInput
                    wrapperClass="mb-4"
                    label="Password"
                    id="form5"
                    type="password"
                    size="lg"
                    onChange={handlePasswordChange}
                  />

                  <input
                    type="file"
                    onChange={handleFileChange}
                    accept="image/*"
                    required
                  />
                  <br />

                  <button type="button" onClick={handleCameraCapture}>
                    Take a Photo
                  </button>
                  {cameraImage && (
                    <img
                      src={cameraImage}
                      alt="Camera"
                      style={{ maxWidth: "50%", marginTop: "10px" }}
                    />
                  )}

                  <div className="d-flex justify-content-end pt-3">
                    <MDBBtn
                      className="ms-2"
                      color="warning"
                      size="lg"
                      onClick={onSubmit}
                    >
                      Sign Up
                    </MDBBtn>
                  </div>
                </MDBCardBody>
              </MDBCol>
            </MDBRow>
          </MDBCard>
        </MDBCol>
      </MDBRow>
    </MDBContainer>
  );
}

export default Register;
