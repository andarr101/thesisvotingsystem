import React, { useEffect, useState } from "react";
import { useLocation } from "react-router-dom";
import { MDBBtn } from 'mdb-react-ui-kit';
import Navbar from "../components/Navbar";
import "../css/VotingDetails.css";
import VotingResultsChart from "../components/VotingResultsChart";

const VotingDetails = () => {
  const [voteDetails, setVoteDetails] = useState([]);
  const [pollId, setPollId] = useState(null);
  const { search } = useLocation();
  const params = new URLSearchParams(search);
  const id = params.get("id");
  const token = localStorage.getItem("token");

  useEffect(() => {
    fetch(`http://127.0.0.1:5000/api/polls?id=${id}`, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    })
      .then((response) => response.json())
      .then((data) => {
        setVoteDetails(data.response);
      })
      .catch((error) => console.error("Error fetching vote details: ", error));

    getIdFromUrl();
  }, []);

  useEffect(() => {
    fetch(`http://127.0.0.1:5000/api/polls?id=${id}`, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    })
      .then((response) => response.json())
      .then((data) => {
        setVoteDetails(data.response);
      })
      .catch((error) => console.error("Error fetching vote details: ", error));

    getIdFromUrl();
  }, []);

  const getIdFromUrl = () => {
    const urlParams = new URLSearchParams(window.location.search);
    const idFromUrl = urlParams.get("id");
    setPollId(idFromUrl);
  };

  const handleCameraCapture = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true });
      const video = document.createElement("video");
      document.body.appendChild(video);
      video.srcObject = stream;
      await video.play();

      const canvas = document.createElement("canvas");
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      canvas
        .getContext("2d")
        .drawImage(video, 0, 0, canvas.width, canvas.height);
      const imageUrl = canvas.toDataURL("image/png");

      stream.getTracks().forEach((track) => track.stop());
      video.remove();
      canvas.remove();

      return imageUrl;
    } catch (error) {
      console.error("Error accessing camera:", error);
    }
  };

  const getStatus = () => {
    let status = localStorage.getItem("status");
    return status.includes("CLOSED");
  };
  const isVoteClosed = getStatus();

  const submitVote = async (imgUrl, voteId) => {
    const formData = new FormData();
    formData.append("pollId", pollId);
    formData.append("candidateId", voteId);

    if (imgUrl) {
      const blob = await fetch(imgUrl).then((response) => response.blob());
      formData.append("face_photo", blob, "camera-image.png");
    }

    try {
      const response = await fetch(
        "http://127.0.0.1:5000/api/vote",
        {
          method: "POST",
          body: formData,
          headers: {
            Authorization: "Bearer " + token,
          },
        }
      );

      const data = await response.json();
      alert(data.response);
    } catch (error) {
      console.error("Error during registration:", error);
    }
  };

  const handleVote = async (vote) => {
    const imgUrl = await handleCameraCapture();
    setTimeout(() => submitVote(imgUrl, vote.id), 5000);
  };

  return (
    <>
      <Navbar />
      <div className="container">
        <h3>{voteDetails.name}</h3>
        <h5>{voteDetails.description}</h5>
        <h5>Open until: {voteDetails.openUntil}</h5>

        {!isVoteClosed &&
          voteDetails &&
          voteDetails.candidates &&
          Array.isArray(voteDetails.candidates) && (
            <div style={{marginTop: '20px'}}>
              {voteDetails.candidates.map((candidate, index) => (
                <div key={index} className="vote">
                  <MDBBtn
                    className="me-1"
                    color="success"
                    onClick={() => handleVote(candidate)}
                  >
                    {candidate.name}
                  </MDBBtn>
                </div>
              ))}
            </div>
          )}

        {Array.isArray(voteDetails.results) &&
          voteDetails.results.length &&
          isVoteClosed && (
            <div>
              <VotingResultsChart
                votingResults={voteDetails.results}
                candidateNames={voteDetails.candidates}
              />
            </div>
          )}
      </div>
    </>
  );
};

export default VotingDetails;
