from facepplib import FacePP, exceptions


def _face_comparing(app, Image1, Image2):
    cmp_ = app.compare.get(image_url1=Image1, image_url2=Image2)

    if cmp_.confidence > 70:
        return {
            "status": True,
            "percentage": str(cmp_.confidence) + '%',
            "errors": None
        }
    else:
        return {
            "status": False,
            "percentage": str(cmp_.confidence) + '%',
            "errors": None
        }


def compare(image1_url, image2_url):
    api_key = 'xQLsTmMyqp1L2MIt7M3l0h-cQiy0Dwhl'
    api_secret = 'TyBSGw8NBEP9Tbhv_JbQM18mIlorY6-D'

    app_ = FacePP(api_key=api_key, api_secret=api_secret)
    try:
        return _face_comparing(app_, image1_url, image2_url)
    except exceptions.BaseFacePPError as e:
        return {
            'status': None,
            'percentage': None,
            'errors': e.args[0]
        }
