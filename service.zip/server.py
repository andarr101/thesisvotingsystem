import datetime
import uuid
import os
import face_comparator

from flask import Flask, request
from flask_cors import CORS
from azure.storage.blob import BlobServiceClient, generate_blob_sas, BlobSasPermissions
from datetime import datetime, timedelta

app = Flask(__name__)
env_config = os.getenv("APP_SETTINGS", "config.DevelopmentConfig")
app.config.from_object(env_config)
CORS(app)


@app.route('/ping', methods=['GET'])
def ping():
    return "OK!"


def delete_image(file):
    connection_string = app.config['STORAGE_CONTAINER']
    blob_service_client = BlobServiceClient.from_connection_string(connection_string)
    container_name = "images"
    container_client = blob_service_client.get_container_client(container_name)

    blob_name = file.filename
    blob_client = container_client.get_blob_client(blob_name)
    blob_client.delete_blob()


def upload_image(file):
    connection_string = app.config['STORAGE_CONTAINER']
    blob_service_client = BlobServiceClient.from_connection_string(connection_string)
    container_name = "images"
    container_client = blob_service_client.get_container_client(container_name)

    blob_name = file.filename
    blob_client = container_client.get_blob_client(blob_name)
    blob_client.upload_blob(file.stream)


def generate_sas(file):
    connection_string = app.config['STORAGE_CONTAINER']
    blob_service_client = BlobServiceClient.from_connection_string(connection_string)
    container_name = "images"
    container_client = blob_service_client.get_container_client(container_name)

    blob_name = file.filename
    blob_client = container_client.get_blob_client(blob_name)

    expiry = datetime.utcnow() + timedelta(minutes=1)

    sas_token = generate_blob_sas(
        account_name=blob_service_client.account_name,
        container_name=container_name,
        blob_name=blob_name,
        account_key=blob_service_client.credential.account_key,
        permission=BlobSasPermissions(read=True),
        expiry=expiry
    )

    return f"{blob_client.url}?{sas_token}"


@app.route('/validate_face', methods=['POST'])
def validate_face():
    if "file1" not in request.files:
        return "No file1 part"

    if "file2" not in request.files:
        return "No file2 part"

    file1 = request.files["file1"]
    if file1.filename == "":
        return "No selected file", 400
    file2 = request.files["file2"]
    if file2.filename == "":
        return "No selected file", 400

    file1.filename = str(uuid.uuid4())
    file2.filename = str(uuid.uuid4())

    upload_image(file1)
    upload_image(file2)

    image1_url = generate_sas(file1)
    image2_url = generate_sas(file2)

    result = face_comparator.compare(image1_url, image2_url)

    delete_image(file1)
    delete_image(file2)

    return result, 200


if __name__ == '__main__':
    print(f"Application started")
    app.run(port=5001)
